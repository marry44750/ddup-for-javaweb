define(["jquery", "froala_editor"], function($) {
    $(function() {
      $('#edit').editable({inlineMode: false})
    });
});